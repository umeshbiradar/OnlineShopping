package com.edubridge.serviceimpl;

/*import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.repository.OrderRepository; */
import com.edubridge.service.OrderService; 
//@Service
public class OrderServiceImpl implements OrderService {

//	@Autowired
//	private OrderRepository orderRepository;
}
