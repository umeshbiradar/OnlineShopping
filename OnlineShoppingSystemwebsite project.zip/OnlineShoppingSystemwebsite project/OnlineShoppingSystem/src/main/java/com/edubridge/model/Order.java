package com.edubridge.model;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonFormat;

//	@Entity
//	@Table(name="order")
	public class Order {
/*		@Id
		@SequenceGenerator(name="seq_order",sequenceName="OrderSequence1",initialValue=100,allocationSize=100)
	    @GeneratedValue(generator="seq_order")
		private int orderId;
		@JsonFormat(pattern="yyyy/mm/dd")
		@Column(name="order_date")
		private Date orderDate;
		@Column(name="order_status")
		private String orderStatus;
		@Column(name="total_price")
		private int totalPrice;
		
		public Order() {
			
		}
		
		public Order(int orderId, Date orderDate, String orderStatus, int totalPrice) {
			super();
			this.orderId = orderId;
			this.orderDate = orderDate;
			this.orderStatus = orderStatus;
			this.totalPrice = totalPrice;
		}

		public int getOrderId() {
			return orderId;
		}

		public void setOrderId(int orderId) {
			this.orderId = orderId;
		}

		public Date getOrderDate() {
			return orderDate;
		}

		public void setOrderDate(Date orderDate) {
			this.orderDate = orderDate;
		}

		public String getOrderStatus() {
			return orderStatus;
		}

		public void setOrderStatus(String orderStatus) {
			this.orderStatus = orderStatus;
		}

		public int getTotalPrice() {
			return totalPrice;
		}

		public void setTotalPrice(int totalPrice) {
			this.totalPrice = totalPrice;
		}

		@Override
		public String toString() {
			return "Order [orderId=" + orderId + ", orderDate=" + orderDate + ", orderStatus=" + orderStatus
					+ ", totalPrice=" + totalPrice + "]";
		}  */
	}
		