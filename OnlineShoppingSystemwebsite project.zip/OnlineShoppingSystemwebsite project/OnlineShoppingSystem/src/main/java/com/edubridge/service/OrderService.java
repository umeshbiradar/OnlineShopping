package com.edubridge.service;

public interface OrderService {

}
